254321 Antoni Fornés antoni.fornes01@estudiant.upf.edu 
251247 Pol Brugarolas pol.brugarolas01@estudiant.upf.edu

WELCOME TO OUR PAINT LAB

To run it you only have to Run the whole program and a screen with a toolbar will appear. Then you have two options: change the method you want to draw by clicking in the toolbar to the right box, also you can change the color of what you want to draw; or choose the method with the keyboard like it follows:
1: Line DDA
2: Line Bresenham
3: Circles
	f: choose if you want it fill or not
4: Painting tool
5: Starwars particle animation

All the methods works with the mouse: you click in one point and then clicking in another point it will make a line between this two points, in the case of circles this line will be the radious distance and in the case of painting tool, you have to keep button clicked or draw.

You can also clear the screen by clicking the white/black sheets of the toolbar, which will fill the screen with balck or white color.

Finally, we have also programmed the functions of toolbar to work in case it's placed at the bottom of the screen, but we haven't implemented it.  

